const deed = artifacts.require("./Deed.sol");

module.exports = async function(deployer) {
  await deployer.deploy(deed, "digitalNotary","DEED")
  const deedContract = await deed.deployed()
};

